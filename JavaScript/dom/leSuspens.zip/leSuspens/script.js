"use strict";

const dark = document.querySelector("#darkTheme");
let r,g,b;

dark.addEventListener("input", changeTheme2);


/* function changeTheme(){
    // Si notre checkbox est cochée, on ajoute le thème dark, sinon on lui retire.
    document.body.classList.toggle("dark", dark.checked);
}
changeTheme(); */

function changeTheme2() {
/*     
    if(dark.checked){
        document.documentElement.style.setProperty("--fond", "#333");
        document.documentElement.style.setProperty("--text", "antiquewhite");
    } else{
        document.documentElement.style.setProperty("--fond", "antiquewhite");
        document.documentElement.style.setProperty("--text", "#333");
    } 
    */
    // Appliquer la couleur aléatoire sur les variables créées dans :root en CSS
    document.documentElement.style.setProperty('--fond', randColor());
    document.documentElement.style.setProperty('--text', randColor());
}

// Créer une couleur aléatoire
function randColor(){
    let rgb = [];
    for (let i = 0; i<3; i++){
        let c = Math.floor(Math.random()*256);
        rgb.push(c);
    }
    return `rgb(${rgb[0]},${rgb[1]},${rgb[2]})`
}